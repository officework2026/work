# WFD_v2 — Workflow Document

**Project:** Lead Lifecycle Management System  
**Version:** 2.0  
**Companion to:** SRD_v2, SDD_v2, STD_v2, KTD_v2  
**Purpose:** Describe every workflow in the application — the paths a user takes through the system, the state each record moves through, the handoffs between roles, the background jobs that run on the server, and the failure paths at each step.

This document is written for three audiences. Business users read §2 through §6 to understand what the system does and in what order. Engineers read §7 through §12 to understand every state machine, every background job, and every failure path. QA reads §13 to see which workflow each test case exercises.

---

## 1. Introduction

### 1.1 What this document is

A workflow is a sequence of steps, each with an actor, an input, and an output, and each with a set of conditions under which it can fail. The SRD states **what** the system must do. The SDD states **how** it is built. The STD states **how it is proven**. This document states **how it flows** — the order in which things happen, the decisions that gate each step, and the states the system can be in at any moment.

### 1.2 Why it exists

The other four documents are organised by requirement, by file, and by test. None of them follows a single user from sign-in to sign-out, or a single lead from creation to `WON`. A new engineer who reads them learns what every piece does but not how the pieces hand off to each other. A QA engineer who reads them learns how to test each requirement but not the order in which the tests reflect a real day of use. This document fills that gap.

### 1.3 Scope

Every workflow in Version 2:

1. The sign-in workflow.
2. The lead creation workflow.
3. The lifecycle workflow — the six stages.
4. The module save workflow — the same pattern applied six times.
5. The bulk upload workflow.
6. The dashboards and radar workflow.
7. The audit and history workflow.
8. The notification workflow.
9. The tab-visibility and configuration workflow.
10. The user management workflow.
11. The reference masters workflow.
12. The backup and restore workflow.
13. The background jobs.
14. The failure and recovery paths.

### 1.4 Notation

Each workflow is drawn as a numbered sequence of steps. A step that can fail carries its failure conditions inline. A step that runs on the server is marked **[S]**. A step that runs in the browser is marked **[C]**. A step that is triggered automatically by a background job is marked **[B]**.

State names are written in `UPPER_SNAKE_CASE`, matching the values stored in the database.

---

## 2. The sign-in workflow

### 2.1 Sequence

1. **[C]** The user opens the application. The client reads `localStorage.user`. If a session exists, the client validates it against `/auth/me` and, on success, jumps to step 8. On failure, it clears `localStorage` and continues to step 2.
2. **[C]** The client loads `public/auth_config.json` and `public/config.json`. The Company, Unit, SBU, and Division dropdowns are populated from the auth config. The service URLs are applied from the runtime config.
3. **[C]** The user picks the **Standard User** tab or the **Director** tab. On the Standard tab, all five fields are visible: Company, Unit, SBU, Division, User ID, Password. On the Director tab, only Company, Unit, User ID, and Password are visible; SBU and Division are hidden.
4. **[C]** The user submits. The client `POST`s `{ userID, password, unit, userCompany, userSbu, userDivision, accessType }` to `/auth/signin`.
5. **[S]** The server:
   - Loads the user by `userID`. **Failure:** `404 User not found`.
   - Compares the decrypted `password` with the submitted one. **Failure:** `401 Invalid Password!`.
   - If `accessType === 'director'` and `userRole !== 'director'`. **Failure:** `403`.
   - If `accessType === 'standard'` and `userRole === 'director'`. **Failure:** `403`.
   - For a standard sign-in, compares `userCompany`, `userSbu`, `userDivision`. **Failure:** `403`. For a director sign-in, compares only `userCompany`.
   - Compares `unit` against `userUnit` if the stored value is not null. **Failure:** `403`.
   - Deletes any existing session row for the user.
   - Mints a JWT with `sub = userID`.
   - Inserts a new session row.
   - Returns `{ id, staffId, username, userRole, userCompany, userSbu, userDivision, userUnit, admin, description, accessToken }`.
6. **[C]** The client writes `localStorage.user` and dispatches the `auth` action into the Redux store.
7. **[C]** The client fetches `/tab-visibility/current` and `/masters` in parallel. The tab-visibility fetch resolves the sidebar. The masters fetch warms the reference cache.
8. **[C]** The client opens the notification WebSocket at `/ws/notifications?token=<accessToken>`.
9. **[C]** The client navigates to `/lead-lifecycle/home`. `HomeRedirect` picks the first tab the caller is allowed to see, in this order: any dashboard, then any radar, then `leads`, then any lifecycle module, then any admin page. If nothing is visible, the client shows an empty home with a message.

### 2.2 Failure paths

| Where | Condition | What the user sees |
|---|---|---|
| Step 5 | Wrong password | `401 Invalid Password!` in an alert on the form. |
| Step 5 | Wrong scope | `403` with the message from the server. The field is focused; the message says which scope field did not match. |
| Step 5 | Wrong access type | `403` with a message that names the correct tab. |
| Step 7 | Tab visibility fetch fails | The sidebar falls back to hardcoded defaults for the role. No error shown to the user; the sidebar may be slightly wider than the matrix says. |
| Step 7 | Masters fetch fails | The master-driven dropdowns are empty. A toast says "Some reference data could not be loaded." The user can still proceed; new values typed into free-text fields will be canonicalised on save. |
| Step 8 | WebSocket fails | The bell shows "Offline". It reconnects with exponential backoff. The REST fallback poll runs every five minutes. |
| Step 9 | Nothing visible | A blank page with a message: "No pages are enabled for your role. Contact your administrator." |

### 2.3 What state the system is in after sign-in

- One `user_sessions` row exists for the user.
- `localStorage.user` is populated.
- The Redux `auth` slice carries the user.
- The `useTabVisibility` hook has a resolved map (or the hardcoded fallback).
- The `useMasters` cache is populated for the caller's scope.
- The WebSocket is open and has received a `hello` message.
- The user is on `/lead-lifecycle/home`.

---

## 3. The lead creation workflow

### 3.1 Sequence

1. **[C]** The user opens `/lead-lifecycle/leads` and clicks **New Lead**. The Lead form mounts with empty fields.
2. **[C]** The form reads the masters cache and populates the dropdowns for Customer, Product, Currency, Lead Source, Business Domain, Segment, Project, Received Via. The **Lead Owner** dropdown is populated from `/users/by-scope`, which returns users in the caller's scope.
3. **[C]** The user fills the form. Required fields are marked with a red asterisk. On submit, the form focuses the first missing field and shows an inline error.
4. **[C]** The client `POST`s the payload to `/leads`.
5. **[S]** The server opens a transaction. Inside it:
   - The server reads `lead_owner_id`. If present, it loads the owner's profile and captures `owner_company`, `owner_sbu`, `owner_division`. If the owner is not in the caller's scope, the server refuses with `403`.
   - The server captures `creator_company`, `creator_sbu`, `creator_division` from `req.user`. This never changes for the life of the lead.
   - For each of `business_domain`, `segment`, `project`: if the submitted value does not exist in the master table for the caller's scope, the server canonicalises it (trim, collapse whitespace, uppercase), inserts a master row with `source = 'service'`, and stores the canonical value on the lead. If two users insert the same new value at the same moment, the second insert is caught and the existing row is reused.
   - The server calls `referenceService.generateUniqueLeadReference(transaction)` to mint `lead_reference_no` from the configured template. It retries up to five times if the candidate collides.
   - The server writes the lead row with `current_stage = ENQUIRY`, `lifecycle_status = ACTIVE`, `current_stage_entered_at = now()`.
   - The server writes `lead_stage_history` with one row: `stage = ENQUIRY`, `entered_at = now()`, `outcome = SUCCESS`.
   - The server calls `audit.recordAudit` with `action = CREATE`.
   - The server commits.
6. **[C]** On success, the client navigates to `/lead-lifecycle/leads/<ref>` and shows a toast: "Lead created: LEAD-YYYY-NNNNN".
7. **[C]** On failure, the client shows the error from the server and leaves the form populated.

### 3.2 Failure paths

| Where | Condition | What the user sees |
|---|---|---|
| Step 3 | Missing mandatory field | Field is focused; inline error. The submit is blocked. |
| Step 5 | Owner outside scope | `403 Owner is outside your scope`. The form is not cleared. |
| Step 5 | Reference generation fails five times | `500 Could not allocate a unique reference`. The user retries; the fifth retry almost always succeeds. |
| Step 5 | Master insert conflict that the server cannot resolve | `409` with a message. The form is not cleared. The user retries; the master row now exists, so the retry succeeds. |
| Step 5 | Any other server error | `500`. The transaction rolls back. No lead row, no history row, no audit row. |
| Step 6 | Network error after a successful write | The lead exists on the server but the client does not know the reference. The client shows "The lead may have been created. Check the Leads list." and reloads the list. |

### 3.3 What state the system is in after creation

- One `leads` row with `current_stage = ENQUIRY`, `creator_*` captured, `owner_*` captured.
- One `lead_stage_history` row for `ENQUIRY`.
- One `audit_log` row with `action = CREATE`.
- Zero module rows.
- Zero attachments, zero notes.
- The lead appears in every list the creator can see, and in the owner's list if the owner is a different person in the same scope.

---

## 4. The lifecycle workflow

### 4.1 The six stages

```
ENQUIRY → QUOTATION → TENDER → BIDDING → ORDER_ACQUISITION → ORDER_RECEIVED
```

Each transition is forward-only and one stage at a time. Each transition requires the **current** stage's data to exist before the next stage can be entered. The mapping from stage to module:

| Stage | Module that must exist to leave it | Module that records the entry |
|---|---|---|
| ENQUIRY | `leads` (always exists) | `leads` |
| QUOTATION | `lead_quotation_details` | `lead_quotation_details` |
| TENDER | `lead_tender_details` | `lead_tender_details` |
| BIDDING | `lead_bidding_details` | `lead_bidding_details` |
| ORDER_ACQUISITION | `lead_order_acq_details` | `lead_order_acq_details` |
| ORDER_RECEIVED | `lead_order_received_details` | `lead_order_received_details` |

### 4.2 The advance rule

A lead can only advance from stage `X` to stage `next(X)`. Any attempt to skip is refused. The server checks three things inside the transaction that writes the module row:

1. The lead's `current_stage` is `X`.
2. A row exists in `X`'s module table for this lead.
3. No row exists yet in `next(X)`'s module table for this lead.

If all three pass, the server writes the new module row, updates the lead's `current_stage`, and appends a `lead_stage_history` row with `outcome = SUCCESS`. If any fails, the server rolls back and returns a specific error.

### 4.3 Terminal states

Two `lifecycle_status` values end the workflow:

- `WON` — reached when `current_stage = ORDER_RECEIVED`. `actual_close` is set at the transition.
- `LOST`, `CANCELLED`, `EXPIRED` — set by an administrator from the Lead detail page. The stage stays at whatever it was; `lifecycle_status` becomes terminal; `current_stage_entered_at` is frozen.

A lead in a terminal status does not accept new module saves. The Form tab's eligible-lead search excludes it.

### 4.4 The history of a lead

For every lead, the following history exists:

- `lead_stage_history` — one row per transition, with `entered_at`, `exited_at`, `outcome`, `actor_id`.
- `audit_log` — one row per mutation of the lead or any module row.
- `lead_notes` — free-text notes.

These three together are what the History modal renders.

---

## 5. The module save workflow

### 5.1 The same pattern six times

Each of the five module pages (Quotation, Tender, Bidding, Order Acquisition, Order Received) has three tabs. The Form Submission tab is where the workflow lives. The View / Table and Bulk Upload tabs are covered in §5.5 and §6.

### 5.2 The Form Submission tab

1. **[C]** The user opens `/lead-lifecycle/<module>`. The Form tab is active.
2. **[C]** The search bar lists eligible leads. An eligible lead for module `M` is one whose `current_stage` is `prev(M)` or `M`, whose `lifecycle_status` is not terminal, and which does not yet have a row in `M`'s detail table. The dropdown populates on mount, before the user types.
3. **[C]** The user selects a lead. The module form renders, and **all earlier-stage blocks render as read-only** if their rows exist for the lead. A Quotation form for a lead at `QUOTATION` shows the lead header but no earlier blocks (nothing is earlier). A Bidding form for a lead at `BIDDING` shows the Quotation block and the Tender block, read-only.
4. **[C]** The user fills the form. Mandatory fields are marked with a red asterisk. Some modules have child tables (Quotation revisions, Tender partners, Tender competitors, Bidding corrigenda, Order Acq milestones) that are edited inline with `RepeatableRowEditor`.
5. **[C]** The user submits. The client `POST`s to `/<module>`.
6. **[S]** The server opens a transaction. Inside it, in this exact order:
   - **Load the lead and check its stage.** If the lead is not at `prev(M)` or `M`, refuse with `400 Lead is not at the right stage`. If the lead is terminal, refuse with `400 Lead is closed`.
   - **If the lead is at `prev(M)`:** call `leadService.advanceStage(lead, M, transaction)`. This writes the `lead_stage_history` row with `exited_at` for `prev(M)` and `entered_at` for `M`, updates `current_stage`, and, if `M === ORDER_RECEIVED`, sets `lifecycle_status = WON` and `actual_close`.
   - **Write the module header row.** For Quotation, this also writes a revision row.
   - **Write child rows** (partners, competitors, corrigenda, milestones) if the module has them.
   - **Write the audit row** with `action = CREATE` (or `REVISION` for a Quotation that is being revised).
   - **Commit.**
7. **[C]** On success, `SuccessModal` opens. It shows a green tick, the heading "Form submitted successfully", the subheading "Your module details were recorded successfully. You can now submit another form", a read-only field with the lead reference and a copy icon, and two buttons: **Submit another form** and **View submitted data**.
8. **[C]** **Submit another form** clears the loaded lead and the form state. **View submitted data** switches to the View / Table tab and refreshes the list.

### 5.3 The critical ordering invariant

The advance happens **before** the module row is written. This closes the race window where a concurrent reader could see a lead at `M` with no row in `M`'s table. The guard inside `advanceStage` requires the previous stage's data to exist — which it does — and then moves the lead to `M`. Then the module row is written. If the module row write fails, the whole transaction rolls back, including the advance.

### 5.4 Failure paths

| Where | Condition | What the user sees |
|---|---|---|
| Step 5 | Mandatory field missing | Focus on the field; inline error; submit blocked. |
| Step 6 | Lead is terminal | `400 Lead is closed`. The search bar excludes terminal leads, so this only fires if the lead was closed in another tab. |
| Step 6 | Lead advanced since the form loaded | `400 Lead is at <new stage>, not the expected stage`. The form reloads and shows the new stage. |
| Step 6 | Duplicate module row (lead already has one) | `409` with a message naming the existing row. The user is redirected to the View tab. |
| Step 6 | Child row validation fails | `400` with the field name. The transaction rolls back; the lead does not advance. |
| Step 6 | Reference service failure (rare) | `500`. The transaction rolls back. |
| Step 7 | Network error after commit | The client shows "The form may have been submitted. Check the View tab." and switches to the View tab. |
| Step 8 | Copy button fails (no clipboard permission) | A toast: "Could not copy. Reference: LEAD-YYYY-NNNNN". The reference is visible in the field either way. |

### 5.5 The View / Table tab

1. **[C]** The tab fetches `GET /<module>` with the current filters. The server applies `scopeClause(actor)` on the join to `leads`, so no row outside the caller's scope is ever returned.
2. **[C]** The table renders with sticky header, sticky first two columns, and sticky Actions column.
3. **[C]** The search bar matches on `lead_name`, `lead_reference_no`, `crm_lead_no`, `customer_name`, and the module's own searchable columns. The search is combined with the scope clause under `Op.and`, so a scope-excluded row cannot leak through the search.
4. **[C]** The Actions column has four buttons:
   - **Trace** — opens `/lead-lifecycle/leads/<ref>`.
   - **History** — opens the History modal for the lead.
   - **Edit** — opens the module's own form in a modal, with the same dropdowns and mandatory checks as Create.
   - **Delete** — opens a confirm dialog. On confirm, `DELETE /<module>/<ref>`. The delete writes an audit row with `action = DELETE`. The lead's stage does not go back. If the lead was at `M`, it stays at `M`; the stage no longer has data, so any further advance is refused until the module row is re-created.

### 5.6 The module detail page

Each module row has a detail page at `/<module>/<ref>`:

- Header with lead name, reference, stage, status.
- Field grid for the module's own row.
- Child rows (partners, competitors, revisions, etc.) in their own sections.
- **Audit list scoped to this module.** Not to the lead. The Lead detail page is the one that shows the full lifecycle audit.
- **Edit** button — navigates back to the form tab, pre-loaded with the current record.

---

## 6. The bulk upload workflow

### 6.1 The five phases

```
Template → Upload → Validate → Preview & Edit → Re-validate → Commit
```

Each phase has its own state transition on the job record. The job record is the source of truth; the modal is a view of it.

### 6.2 The template phase

1. **[C]** The user clicks **Download Template** on the Bulk Upload tab.
2. **[C]** The browser `GET`s `/bulk/<module>/template`. The server builds the CSV from the module handler's `columns` array and returns it with `Content-Disposition: attachment`.
3. **[C]** The user saves the file, opens it in a spreadsheet, fills rows, and saves as CSV.

The template has two header rows. The first row is the human-readable labels. The second row says `required` or `optional` under each column. The parser reads the first row; the second is informational.

### 6.3 The upload phase

1. **[C]** The user drops the CSV on the drop zone. The client stages the file.
2. **[C]** The user clicks **Validate**. The client sends `multipart/form-data` with field name `file` to `/bulk/<module>/validate`. **It does not set a Content-Type header manually** — Axios sets it with the boundary.
3. **[S]** The server:
   - Parses the CSV. Line endings are normalised (CRLF, CR, LF all work). Quoted fields with commas, double-quotes, and embedded newlines are respected.
   - Maps the labels in the header row to the column keys via the handler's `columns`.
   - For each data row, calls `handler.validateRow(raw)`. The handler returns `[]` or `[{ column, message }]`.
   - Writes a `bulk_upload_jobs` row with `status = VALIDATED`, `total_rows`, `valid_rows`, `invalid_rows`, and `summary_json.rows` carrying the annotated rows.
   - Writes one `bulk_upload_errors` row per error.
   - Returns the job, with `columns` attached so the client can render without a second fetch.

### 6.4 The preview and edit phase

1. **[C]** The `BulkPreviewDialog` opens with `rows` from the job. Each cell is editable. A cell with an error is highlighted with the inline message.
2. **[C]** The user can edit any cell, add a row, or delete a row. Editing a cell clears that cell's error until Re-validate runs again.

The dialog is `maxWidth="xl"`. The row editor has a fixed height and scrolls internally. The page body does not scroll horizontally.

### 6.5 The re-validate phase

1. **[C]** The user clicks **Re-validate**. The client sends `POST /bulk/jobs/:id/revalidate` with `{ rows: [raw, raw, ...] }`. The raw rows are the edited values, not the original file.
2. **[S]** The server:
   - Loads the job and checks the caller's scope.
   - Runs `handler.validateRow` on each sent row. **The uploaded file is not re-read.**
   - Writes the annotated rows back to `job.summary_json.rows`.
   - Rebuilds `bulk_upload_errors`.
   - Returns `{ job, rows }`.

The client replaces its local rows with the response. Edits made before Re-validate are preserved because the server validates the edited rows, not the original file.

### 6.6 The commit phase

1. **[C]** The user clicks **Commit**. The button is disabled while any row has an error. If enabled, the client sends `POST /bulk/jobs/:id/commit` with `{ rows: [...] }`.
2. **[S]** The server:
   - Loads the job; refuses if `status !== VALIDATED`.
   - Re-validates the sent rows once more. If any row is invalid, returns `400 VALIDATION_FAILED` with `details = [{ row, errors }]`. Nothing is written.
   - Sets `status = IMPORTING`.
   - For each row, calls `handler.commitRow(raw, actorId, actorSbu, job.id)` **in its own transaction**. On success, adds to `created`. On failure, adds to `failed` with a code (`CONFLICT` for unique constraint, `FOREIGN_KEY` for a missing reference, `ROW_FAILED` for anything else).
   - If any failed: sets `status = PARTIAL`, saves `summary_json.failed`, returns `409 PARTIAL_COMMIT` with `details = { created, failed }`.
   - If none failed: sets `status = COMPLETED`, saves `summary_json.created`, writes a job-level `BULK_UPLOAD` audit row, returns the job.
3. **[C]** On success, the dialog closes, the file state clears, and the Recent Jobs table refreshes. On failure, the dialog stays open and shows the classified error.

### 6.7 The error classification

The frontend classifier (`bulkErrorClassifier.js`) maps the server error to one of five categories:

| Server response | Category | What the user sees |
|---|---|---|
| `400 VALIDATION_FAILED` with `details` | `VALIDATION` | "N row(s) are still invalid", with a row list. |
| `409 PARTIAL_COMMIT` with `details.failed` | `CONFLICT` | "N row(s) could not be imported", with a row list. |
| `500 DATABASE_ERROR` or `500 SERVER_ERROR` | `SERVER` | "The server could not save this job", with the technical message in an accordion. |
| `504` timeout | `SERVER` | "The server took too long", with advice. |
| No response at all | `NETWORK` | "The request did not reach the server". |

Every error also carries a collapsible **Technical detail** panel with the raw message.

### 6.8 The failure paths

| Where | Condition | What the user sees |
|---|---|---|
| Upload | No file | `400 NO_FILE`. The drop zone is still visible. |
| Upload | File has no data rows | `400 EMPTY_FILE`. |
| Upload | Unknown module | `400 UNKNOWN_MODULE`. |
| Upload | Validation timeout (15 s) | `504`. The job is still created with whatever rows validated before the timeout. |
| Re-validate | Job outside scope | `403`. |
| Re-validate | Job no longer exists | `404`. |
| Commit | Job not in `VALIDATED` | `400 INVALID_STATE`. |
| Commit | Server exception in one row | `409 PARTIAL_COMMIT` with the failed row list. |
| Commit | Database down | `500 DATABASE_ERROR`. |

### 6.9 The revert workflow

A `COMPLETED` job can be reverted from the module's Bulk Upload tab or the Bulk Jobs page.

1. **[C]** The user clicks **Revert** and confirms.
2. **[S]** The server loads the job. Refuses if `status !== COMPLETED`.
3. **[S]** For each row in `summary_json.final_rows`, calls `handler.revertRow(lead_reference_no, job.id)`. The revert removes the module rows the job created. It is best-effort per row — a failure on one row does not abort the others.
4. **[S]** Sets `status = REVERTED`, saves, and **leaves the audit log untouched**. The audit rows remain as the record of what happened, even though the data is gone.

### 6.10 The job-level scope

Every job carries `company`, `sbu`, `division` from the caller at validate time. The list query treats a `null` scope as global (visible to everyone) and a non-null scope as matched (`company = caller.company OR company IS NULL`, and same for `sbu` and `division`). Jobs created before the scope columns existed (all null) stay visible to everyone.

---

## 7. The dashboards and radar workflow

### 7.1 The dashboard load

1. **[C]** The user opens `/lead-lifecycle/dashboard/<name>`. `MarketDashboard` or the corresponding page mounts.
2. **[C]** `useDashboardFetch(path, query)` builds the query string from the `filters` slice. If `filters` is `undefined` (before the store is populated), it uses `{}`.
3. **[C]** The client fetches `GET /dashboard/<name>` from the dashboard-service.
4. **[S]** The dashboard-service verifies the JWT, loads the user, and builds the query through `common.service.buildWhere(query, actor)`. `buildWhere` merges:
   - `scopeClause(actor)` — the `creator OR owner` triple match, or nothing if the actor is a director.
   - The FY window.
   - The FilterBar's search term, year, market, stage.
   - `Op.and` combining all of the above, so the scope clause cannot collide with the search clause.
5. **[S]** The service runs the aggregation queries and returns the dashboard payload.
6. **[C]** Each KPI card and chart renders. Every KPI card is clickable.
7. **[C]** Clicking a KPI card opens the drill modal. The modal fetches `GET /dashboard/<name>/drill?kind=<card>&...`, using the same `windowWhere` or `buildWhere` the dashboard itself used. The drilled rows are scoped identically.

### 7.2 The FilterBar

The FilterBar reads and writes the `filters` slice. Any change dispatches `setFilters`, which re-runs `useDashboardFetch`. There is no page reload. Every widget on the page updates because they all subscribe to the same slice.

The FilterBar fields:

- **Search** — free text. Helper text names the four columns the backend searches.
- **Year** — a calendar-year dropdown, not limited to a five-year window.
- **Market** — `DOMESTIC` or `EXPORT`.
- **Stage** — one of the six stages.

### 7.3 The radar load

1. **[C]** The user opens `/lead-lifecycle/radar/sbu` (the 180° view, every authenticated user) or `/lead-lifecycle/radar/full` (the 360° view, director and admin-like only).
2. **[C]** `useRadarConfig()` loads `public/radar_config.json`. `useRadarLayout()` loads the panel layout through `system_settings.radar_layout`.
3. **[C]** The client fetches `GET /radar/sbu` or `GET /radar/full`.
4. **[S]** The radar-service:
   - `loadSectors({ sbu, company })` — reads `business_domains` filtered by the caller's company and (for the 180° view) SBU. A sector with a null company is global.
   - `buildGeometry(centerFy, sectors, { view, cfg })` — places the sector wedges and the FY bands.
   - Adds a company clause to the lead query. Even a global sector cannot surface a lead from another company.
   - `getRadarData` returns sectors, geometry, and points.
5. **[C]** `RadarChart` renders. The 180° view draws the dashed quarter rings and band outlines in the upper half only. The 360° view draws full circles.
6. **[C]** If the panel layout has more than one panel, `RadarPanelsPage` renders one `RadarPanel` per entry. Each panel has its own scope and filter overrides.

### 7.4 The director exception

A director sees every SBU within their own company on the radar and dashboards. This is the only scope widening in the application other than the superadmin on backup. The widening is applied inside `scopeClause`: when `actor.userRole === 'director'` and the surface is a radar or dashboard, the SBU and division clauses are dropped, leaving only the company clause.

### 7.5 The failure paths

| Where | Condition | What the user sees |
|---|---|---|
| Dashboard load | Token expired | `401`. The client clears `localStorage` and redirects to `/login`. |
| Dashboard load | 360° radar by a non-director | `403`. The page shows "This view requires director access." |
| Drill modal | Row no longer exists | The modal shows fewer rows than the card count. A caption: "Some rows were changed since this count was taken." |
| Radar | Empty scope | The chart renders with a single sector and no points. The empty-state message from `radar_config.json` appears. |
| Radar | Config file corrupt | The chart falls back to bundled defaults. A caption: "Radar configuration could not be loaded; using defaults." |

---

## 8. The audit and history workflow

### 8.1 When an audit row is written

Every write in the application writes one audit row, in the same transaction as the write itself. The write paths that produce audit rows:

| Action | `action` value | Written by |
|---|---|---|
| Lead create | `CREATE` | `lead.service.createLead` |
| Lead update | `UPDATE` | `lead.service.updateLead` |
| Stage advance | `STAGE_ADVANCE` | `lead.service.advanceStage` |
| Module create | `CREATE` | module service |
| Module update | `UPDATE` | module service |
| Module delete | `DELETE` | module service |
| Quotation revision | `REVISION` | `quotation.service.createRevision` |
| Bulk commit | `BULK_UPLOAD` | `bulk.service.commitUpload` |
| Attachment download | `DOWNLOAD` | `download.controller` |

If a write path does not produce an audit row, it is a bug. The audit row carries:

- `module` — the module name.
- `record_ref` — the lead reference or the module's own key.
- `lead_reference_no` — the parent lead.
- `previous_data` — the full row before the write, or `null` for a create.
- `current_data` — the full row after the write, or `null` for a delete.
- `changes` — a diff: `{ fieldName: { previous, current } }` for each field that changed.
- `actor_id` — the user.
- `bulk_job_id` — the job id if the write came from a bulk commit.
- `created_at`.

### 8.2 Reading the audit

Two endpoints:

- `GET /leads/:ref/history` — returns `{ stageHistory, audit, notes }`. The audit is every row for the lead, across every module.
- `GET /modules/:module/:ref/history` — returns `{ audit }` for one module only.

The History modal has two tabs:

- **Audit Log** — a stage timeline, a flat audit list, and the notes.
- **Full Trace** — audit entries grouped by stage, with each entry's content visible inline.

A module detail page shows **only** the module's own audit. The Lead detail page shows the full lifecycle audit, because the lead is the parent.

### 8.3 The retention rule

The audit log is retained indefinitely. It is never deleted by the application. A manual administrative action outside the application is the only way to remove a row.

---

## 9. The notification workflow

### 9.1 The WebSocket connection

1. **[C]** On sign-in, the client opens `ws://<form-service>/ws/notifications?token=<accessToken>`.
2. **[S]** The server verifies the token. If invalid, or the user is inactive, it closes with code `4401`.
3. **[S]** On success, the socket is registered in the `Map<userID, Set<WebSocket>>` in `notification_socket.service.js`. The server sends `{ type: 'hello' }`.
4. **[S]** The server sends a heartbeat ping every 30 seconds. A socket that fails to pong within one cycle is closed and removed from the map.

### 9.2 Delivery

1. **[S]** Whenever `notification.service.ensure` inserts a new notification for a user, it calls `publishToUser(userID, payload)`.
2. **[S]** `publishToUser` iterates every open socket for that user and sends `{ type: 'notification', data: {...} }`.
3. **[C]** `useNotificationSocket` receives the message and dispatches it into the `auth` slice. The `NotificationBell` re-renders.

### 9.3 The three notification kinds

| Kind | When generated | Dedupe key |
|---|---|---|
| `SUBMISSION_DUE` | A lead's `expected_close` is within 7 days. | `SUBMISSION_DUE:<ref>:<YYYY-MM-DD>` |
| `STAGE_STALLED` | A lead has been in its current stage for more than 30 days. | `STAGE_STALLED:<ref>:<stage>:<YYYY-MM>` |
| `TARGET_CROSSED` | A lead's `expected_close` is in the past and the lead is not terminal. | `TARGET_CROSSED:<ref>:<YYYY-MM-DD>` |

The dedupe key makes generation idempotent. Running the job twice in one day produces one notification per (lead, kind, day-or-month).

### 9.4 The REST fallback

If the WebSocket is blocked by a proxy, the socket reconnects with exponential backoff but never succeeds. The bell shows "Offline". The client falls back to `GET /notifications/unread-count` every five minutes. The bell shows the same number the socket would have delivered. The unread count is the only thing the fallback cannot deliver live — the message itself arrives on the next poll.

### 9.5 The failure paths

| Where | Condition | What the user sees |
|---|---|---|
| WebSocket open | Token invalid | Socket closes with `4401`. The client does **not** reconnect. The bell shows "Offline". |
| WebSocket open | Token expired mid-session | Socket closes with `4401` on the next heartbeat cycle. Same as above. |
| WebSocket open | Server restart | Socket closes with `1006`. The client reconnects with backoff. |
| Heartbeat | No pong in one cycle | The server closes the socket. The client reconnects. |
| REST fallback | Non-200 response | The bell keeps its previous count. A console warning appears. |

---

## 10. The tab-visibility and configuration workflow

### 10.1 Resolving visibility for a caller

1. **[C]** `useTabVisibility` calls `GET /tab-visibility/current`.
2. **[S]** The service `getForCurrentUser(user)` resolves each tab key in this order:
   - A user-specific row for the caller's scope: `(company, sbu, division, user_id = caller, role = caller.role, tab_key)`.
   - A role-level row for the caller's scope: `(company, sbu, division, user_id = null, role = caller.role, tab_key)`.
   - The hardcoded default for the caller's role.
3. **[S]** The result is a dense map of every tab key to a boolean.
4. **[C]** The hook stores the map. The sidebar and every `TabGuard` read from it.

### 10.2 The role matrix

1. **[C]** An admin-like user opens `/lead-lifecycle/admin/tab-visibility`, Role Matrix tab.
2. **[C]** The page calls `GET /admin/tab-visibility`. The server returns `{ tabKeys, roles, matrix, scope }`. The `matrix` is dense for every cell.
3. **[C]** The page renders a grid. Each cell is a checkbox. A toggle updates local state only; nothing is written until Save.
4. **[C]** On Save, the page sends **one** `PUT /admin/tab-visibility` with the whole matrix.
5. **[S]** The service iterates every cell and calls `upsertCell` per cell. `upsertCell` does `findOne` → `save` if found, or `create` → on unique-constraint `findOne` again and `save`. Concurrent admins writing the same cell produce no error.
6. **[C]** The page swaps local state with the server's fresh response. A success alert appears.

### 10.3 The user overrides tab

Only `administrator` sees this tab. The flow:

1. **[C]** The page lists users in the administrator's scope through `GET /users`.
2. **[C]** The administrator picks a user. The page calls `GET /admin/tab-visibility/users/:userID`.
3. **[S]** The server returns the user's role, the role-level matrix, the user-specific overrides, and a merged matrix where the user's overrides have been applied on top of the role matrix.
4. **[C]** Each row shows the effective value, the source (`Role default` or `Override`), and a **Clear override** button if the row has an override.
5. **[C]** On Save, `PUT /admin/tab-visibility/users/:userID` with the matrix. The server writes one row per tab key the user's role differs from the role-level row.
6. **[C]** On Clear override, `DELETE /admin/tab-visibility/users/:userID/:tabKey`. The server removes the override row. The role default applies again.

### 10.4 The reference ID configuration

1. **[C]** An admin-like user opens `/lead-lifecycle/admin/reference`.
2. **[C]** The page calls `GET /reference/formats` and shows the current templates for each reference type.
3. **[C]** The page shows a live example for each template, computed client-side from the placeholders.
4. **[C]** On Save, `PUT /reference/formats` with the new templates.
5. **[S]** The server validates the templates (every placeholder is known, `{SEQ:n}` has a valid `n`), writes to `system_settings.reference_formats`, and returns.
6. **[S]** The next reference generated uses the new template. No rebuild, no restart.

### 10.5 The runtime configuration

1. **[C]** On boot, the client fetches `public/config.json`.
2. **[C]** If the file exists and is valid JSON, the client replaces its Axios instances with the URLs from the file.
3. **[C]** If the file is missing or corrupt, the bundled defaults from `src/config.json` take over silently.
4. **[C]** No restart is needed for a config change. The next request uses the new URLs.

### 10.6 The failure paths

| Where | Condition | What the user sees |
|---|---|---|
| Resolve visibility | Server error | The hook falls back to the hardcoded defaults. A console warning appears. |
| Save role matrix | Server error | The alert shows the error message. Local state is not cleared. |
| Save role matrix | Concurrent save by another admin | Both succeed. The last writer wins per cell. |
| User overrides | User outside scope | `403 User is outside your scope`. |
| User overrides | User not found | `404`. |
| Reference formats | Invalid template | `400` with the specific error. |
| Runtime config | File unreadable | Bundled default. No message. |

---

## 11. The user management workflow

### 11.1 The creation flow

1. **[C]** An admin-like user opens `/lead-lifecycle/admin/users`, Create tab.
2. **[C]** The form offers the six roles: `superadmin`, `administrator`, `admin`, `director`, `executive`, `operator`.
3. **[C]** The admin fills the fields and submits. `POST /users`.
4. **[S]** The server verifies the caller's scope. The new user's `company`, `sbu`, `division` must match the caller's. **Failure:** `403`.
5. **[S]** The server validates the role against `VALID_ROLES`.
6. **[S]** The server encrypts the password, writes the row, and returns it.

### 11.2 The update flow

`PUT /users/:id` follows the same scope check. The caller can update a user only in their own scope. The update cannot change `userID`. The password can be reset by an admin-like user in scope.

### 11.3 The delete flow

`DELETE /users/:id` refuses if the target is the caller themselves (`400`). Otherwise the delete is scoped. A deleted user's historical `audit_log` rows remain, because the audit log is immutable.

### 11.4 The failure paths

| Where | Condition | What the user sees |
|---|---|---|
| Create | Target outside scope | `403`. |
| Create | Duplicate `userID` | `409`. |
| Create | Invalid role | `400`. |
| Update | Target outside scope | `403`. |
| Delete | Self-delete | `400`. |
| Delete | User has audit rows | The delete succeeds. The audit rows remain and refer to a user that no longer exists; the History modal shows the `userID` string, not the name. |

---

## 12. The reference masters workflow

### 12.1 The read flow

1. **[C]** Any authenticated user opens `/lead-lifecycle/admin/references` (read-only for non-admin).
2. **[C]** The page calls `GET /masters` for the union of `ui` and `service` rows plus values already on leads.
3. **[C]** By default, service rows are hidden. A toggle includes them. This is the `FR-MST-005` rule.

### 12.2 The CRUD flow

1. **[C]** An admin-like user in scope can create, update, and delete master rows through the page.
2. **[S]** Every write is scoped. A write outside the caller's scope is `403`.
3. **[S]** Every write checks the `(code, company, sbu, division)` uniqueness. A duplicate is `409`.
4. **[S]** Service rows (`source = 'service'`) are created only by the lead service and the bulk upload. The admin page can edit them but the toggle keeps them hidden by default.

### 12.3 The lead-driven creation

When a lead or a bulk row carries a `business_domain`, `segment`, or `project` value that does not exist in the master table for the caller's scope, the lead service canonicalises the value and inserts a master row with `source = 'service'`, scoped to the caller. Two concurrent inserts of the same value both succeed; the second finds the row the first created and reuses it.

---

## 13. The backup and restore workflow

### 13.1 The superadmin isolation

Every route in `backup.routes.js` requires `verifyToken` (from `authJwt`) and the controller runs `superAdminOnly`. If the caller is not `superadmin`, the response is `403 Only superadmin can manage backups`. The role is deliberately narrow: `superadmin` can do nothing else — not user management, not references, not tab visibility.

### 13.2 The manual backup flow

1. **[C]** The superadmin opens `/lead-lifecycle/admin/backup` and clicks **Run Backup Now**.
2. **[S]** The controller calls `backupService.runBackup('MANUAL', actorId, actorScope)`.
3. **[S]** The service:
   - Resolves `pg_dump` via `resolvePgBinary` (PATH, then `pgBinDir`, then Windows standard paths).
   - Spawns `pg_dump -F p -f <target>/db.sql`.
   - Optionally copies `uploads/` to `<target>/uploads/`.
   - Measures the directory size.
   - Writes `backup_runs` with `status = SUCCESS` or `FAILED` and the appropriate fields.
   - Calls `pruneOldBackups(retention)`.
4. **[C]** The page refreshes the list. The new run is at the top.

### 13.3 The scheduled backup flow

1. **[S]** On boot, `applySchedule()` reads `system_settings.backup_config`. If `enabled`, it schedules a job with `node-schedule`.
2. **[S]** When the schedule fires, the job calls `runBackup('SCHEDULED', null, null)`. No actor ID, no actor scope. The run is written with null actor columns. That is correct — the run is not attributable to a user.
3. **[S]** A failure is caught, logged, and the `backup_runs` row is marked `FAILED`. The process is not killed.

### 13.4 The restore flow

1. **[C]** The superadmin clicks **Restore** on a run and confirms with the phrase `RESTORE`.
2. **[S]** The server validates: the source is `SUCCESS`, the dump file exists.
3. **[S]** The server calls `runBackup('MANUAL', actorId, actorScope)` first — a **safety backup**. If the safety fails, the restore is refused.
4. **[S]** The server spawns `psql` to terminate active connections, drop the database, recreate it, and load the dump.
5. **[S]** If `restoreAttachments` is true and the source has an `uploads/`, the uploads directory is replaced.
6. **[S]** A new `backup_runs` row is written with `trigger = RESTORE` and `status = SUCCESS` or `FAILED`.

### 13.5 The diagnostic flow

`GET /backup/diagnose` returns the resolved `pg_dump` and `psql` paths, their versions, and whether the backup and uploads directories exist. This is the first tool to run when a backup fails with `ENOENT` or an empty directory.

### 13.6 The failure paths

| Where | Condition | What the user sees |
|---|---|---|
| Manual backup | `pg_dump` not found | `500` with a message naming the missing binary and pointing at `pgBinDir`. |
| Manual backup | Directory not writable | `500` with the OS error. |
| Scheduled backup | Any failure | The run is marked `FAILED`. No user is notified. The log carries the error. |
| Restore | Source not `SUCCESS` | `400 Only successful backups can be restored`. |
| Restore | Dump file missing | `400` naming the missing file. |
| Restore | Safety backup fails | `500`. The restore does not proceed. The source is untouched. |
| Restore | Database load fails | `500`. The database may be in an intermediate state. The safety backup from step 3 is the recovery path. |

---

## 14. The background jobs

Version 2 runs four background jobs. Each is described here with its schedule, its idempotency rule, and its failure mode.

### 14.1 The notification generation job

- **Schedule:** every six hours, plus once at boot.
- **What it does:** iterates leads whose `expected_close` is within 7 days (for `SUBMISSION_DUE`), leads whose `current_stage_entered_at` is more than 30 days ago (for `STAGE_STALLED`), and leads whose `expected_close` is in the past and are not terminal (for `TARGET_CROSSED`). Calls `notification.service.ensure(notification)` for each.
- **Idempotency:** `ensure` uses the `dedupe_key`. Two runs in the same day produce one row per `(lead, kind, day-or-month)`.
- **Failure:** a single lead that fails is logged and skipped. The job continues. If the whole job throws, the scheduler logs it and reschedules.
- **Delivery:** every insert calls `publishToUser`. If the user has no open socket, the row is still there for the REST fallback.

### 14.2 The backup scheduler

- **Schedule:** from `system_settings.backup_config`. Default `DAILY` at `02:00`.
- **What it does:** calls `runBackup('SCHEDULED', null, null)`.
- **Idempotency:** each run produces a new `backup_runs` row with a unique timestamp. Two runs in the same minute would produce two rows — the folder names include the ISO timestamp to the millisecond, so they do not collide.
- **Failure:** caught, logged, and the run is marked `FAILED`. `pruneOldBackups` runs regardless.

### 14.3 The cleanup job

- **Schedule:** daily at `03:00`.
- **What it does:** deletes `download_tokens` rows whose `expiresAt` is in the past. Deletes `notifications` rows older than 90 days. Deletes `bulk_upload_errors` rows whose `job_id` refers to a job older than 30 days.
- **Idempotency:** the delete is filtered by date, so running the job twice is harmless.
- **Failure:** a failed delete is logged. The job continues to the next table.

### 14.4 The audit integrity check

- **Schedule:** not scheduled by default. Available as a manual run.
- **What it does:** for each lead, counts the mutations recorded in `audit_log` and compares to a stored counter, if one is being maintained. Reports leads whose counts disagree.
- **Idempotency:** read-only.
- **Failure:** read errors are logged. The check is diagnostic, not corrective.

---

## 15. The failure and recovery paths

### 15.1 The failure taxonomy

Every failure in the application falls into one of five categories. The category determines who the user can ask for help and what they can do themselves.

| Category | What happened | Who can fix it | What the user sees |
|---|---|---|---|
| **Validation** | The user's input does not satisfy a rule. | The user. | A field-level error or a row-level error in a modal. |
| **Authorization** | The user is not allowed to do this. | The user, or their administrator. | `403` with a message naming the required role. |
| **Scope** | The data belongs to another scope. | An administrator in that scope. | `404` for reads (to avoid revealing existence), `403` for writes. |
| **Conflict** | The state has changed since the user loaded the page. | The user, by reloading. | `409` with a message naming the stale data. |
| **Server** | The server could not complete the operation. | The engineering team. | `500` with a message that says it is a server-side problem. The dialog shows the technical detail in a collapsible panel. |

The error classifier in `bulkErrorClassifier.js` is the reference implementation of this taxonomy. Every other surface follows the same pattern: validation is inline, authorization and scope are named, conflict is described, server is technical-detail-in-accordion.

### 15.2 The transaction boundary as the recovery mechanism

Because every multi-step write happens inside a single `sequelize.transaction`, any failure at any step rolls the whole thing back. The user is left in the exact state they were in before the request, and the fix is always "try again, possibly with different input". There is no partial state to clean up.

The one deliberate exception is the bulk commit, where each row is its own transaction, because a partial commit is a supported outcome. The `PARTIAL` status is the record of that outcome, and the `failed` list is the recovery path: the user edits the failed rows and runs a new job with them.

### 15.3 The recovery playbook

| Symptom | First action | Escalation |
|---|---|---|
| A form will not save | Check the field errors; re-read the mandatory-field rules. | If the error names a server problem, capture the technical detail from the collapsible panel. |
| A lead is not visible | Check the caller's scope. If the lead was created by someone else, is the caller the owner? If not, it is correctly invisible. | If the caller should see it, check the `creator_*` and `owner_*` columns directly. |
| A bulk upload fails at commit | Read the classified error. `VALIDATION` means edit the row. `CONFLICT` means the row duplicates existing data. `SERVER` and `NETWORK` are transient. | If the error is `SERVER`, capture the technical detail and the job id. |
| The notification bell shows Offline | Sign out and sign in. If it stays offline, the WebSocket path is blocked by a proxy. | The REST fallback keeps the count correct even when the socket is down. |
| A backup fails with `ENOENT` | Run `GET /backup/diagnose`. It names the resolved path. Set `pgBinDir` to the folder that contains `pg_dump`. | If the binary is genuinely missing, install the PostgreSQL client tools. |
| A restore left the database in an intermediate state | The safety backup taken at step 3 is the recovery path. Run another restore from that backup. | If the safety backup is also gone, the pre-restore backup on disk is the last resort. |
| A dashboard shows fewer rows than expected | Reset the FilterBar to "All". The dashboard applies the FY window; the Lead list does not. If the numbers still differ, the dashboard is counting only open statuses. | If the caller is not a director, this is correct behaviour. |
| A radar is empty | Check the caller's scope. A 180° radar is restricted to the caller's SBU. | A 360° radar is restricted to the caller's company. A sector with a null company is visible to all, but a lead from another company is not. |

### 15.4 The rollback path for a deployment

A deployment is rolled back when any smoke test fails. The rollback steps:

1. Stop the three processes.
2. Restore the previous release of the three deployable units.
3. If the release included a schema migration, the migration is not reversible in Version 2. The database stays at the new schema; the old code is deployed against it. Version 2's schema changes are additive (new columns, new tables) so the old code continues to work. If a migration is destructive, that is a bug in the migration, and the safety backup from before the deploy is the recovery path.
4. Start the three processes.
5. Run the smoke suite.

The three deployable units are independent. A rollback of the frontend does not require a rollback of the backend, and vice versa, as long as the API contract has not changed.

### 15.5 The scope-rule recovery

The scope rule is the most security-sensitive part of the application. If a bug is suspected:

1. Reproduce with two users in different SBUs and one in a different company. Fixtures A and C from the STD cover this.
2. Confirm the failing endpoint goes through `scopeClause`. If it does, the bug is in `scopeClause`; fix in one place, redeploy, run `TC-QA-013`.
3. If it does not, the bug is a missing call. Add the call and add a test.
4. If the bug is on a surface that must be exempted (`director` on radar/dashboards, `superadmin` on backup), verify the exemption is the only exemption. Any other exemption is a security bug.

### 15.6 The audit-rule recovery

If an audit row is missing:

1. Identify the write path that should have produced it.
2. Confirm the path calls `recordAudit` inside the same transaction as the write.
3. If the call exists but the row is missing, the transaction rolled back — which is correct.
4. If the call does not exist, add it, add a test, and backfill the missing row from the `previous_data` and `current_data` in a hand-written migration if the write already happened.

A write without an audit row is a bug. The rule has no exceptions.

---

## 16. The end-to-end story

To see all the workflows together, follow one lead from creation to `WON`.

**Monday, 09:00.** An operator in `BEL/S1/D1` signs in. The sign-in workflow runs. The sidebar shows only what the tab-visibility matrix allows.

**Monday, 09:05.** The operator creates a lead for a customer. The lead creation workflow runs. The lead is `ENQUIRY`. An audit row records the create. A stage-history row records entry to `ENQUIRY`.

**Monday, 09:10.** The customer accepts a quotation. The operator opens the Quotation form, selects the lead, fills the form, submits. The module save workflow runs: the lead advances to `QUOTATION` and the quotation row is written in one transaction. The success modal opens. The operator copies the reference and clicks "Submit another form".

**Tuesday, 10:00.** The notification job runs. The lead's `expected_close` is within 7 days, so a `SUBMISSION_DUE` notification is generated. The operator's socket receives it. The bell shows a badge.

**Wednesday, 14:00.** The operator uses Bulk Upload to add three tender partners. The bulk upload workflow runs: template, upload, validate, preview, re-validate, commit. The commit succeeds; the job is `COMPLETED`. A `BULK_UPLOAD` audit row records the job.

**Friday, 16:00.** The director opens the Radar. The radar workflow runs. The director is company-wide on the radar; the SBU view is limited to the caller's SBU but the director sees every SBU. The lead appears in the correct sector.

**The following Monday.** The lead is at `ORDER_RECEIVED`, `WON`. A second audit row records the transition. The History modal shows the full lifecycle: every stage, every field change, every note, in order.

**The following month.** A superadmin runs a backup. The backup service writes a dump and prunes the old ones. A year later, if the lead's row is ever in dispute, the audit log has the full story, and the backup has the data.

That is the whole application. Every workflow in this document is one path through that story. The SRD says what each step must do. The SDD says how each step is built. The STD says how each step is proven. This document says how the steps connect. Together, the five documents are the full picture.

---

## 17. Appendix — workflow index

| Workflow | Section | Primary roles | Primary test cases |
|---|---|---|---|
| Sign-in | §2 | All | TC-SMK-002, TC-AUTH-001 to TC-AUTH-017 |
| Lead creation | §3 | Operator, executive, admin | TC-LEAD-001, TC-LEAD-004, TC-LEAD-005, TC-LEAD-006 |
| Lifecycle | §4 | Operator, admin | TC-STG-001 to TC-STG-003 |
| Module save | §5 | Operator, admin | TC-MOD-001 to TC-MOD-015, TC-LEAD-016, TC-LEAD-017 |
| Bulk upload | §6 | Operator, admin | TC-BULK-001 to TC-BULK-017 |
| Dashboards and radar | §7 | All (scope-bound), director (company-wide) | TC-DASH-001 to TC-DASH-011, TC-RAD-001 to TC-RAD-012 |
| Audit and history | §8 | All | TC-AUD-001 to TC-AUD-013 |
| Notifications | §9 | All | TC-NOTIF-001 to TC-NOTIF-007 |
| Tab visibility | §10 | Admin-like; administrator for user overrides | TC-TAB-001 to TC-TAB-009 |
| User management | §11 | Admin-like | TC-USER-001 to TC-USER-008 |
| Reference masters | §12 | Admin-like for writes; all for reads | TC-MST-001 to TC-MST-008 |
| Backup and restore | §13 | Superadmin only | TC-BAK-001 to TC-BAK-008 |
| Background jobs | §14 | — | TC-NOTIF-005, TC-BAK-002, TC-BAK-003 |
| Failure and recovery | §15 | All | TC-SEC-001 to TC-SEC-014, TC-QA-013, TC-QA-014 |

---

**End of WFD_v2.**

The five documents are now complete:

- **SRD_v2** — what the system must do.
- **SDD_v2** — how the system is built.
- **STD_v2** — how each requirement is proven.
- **KTD_v2** — how a new engineer learns the system.
- **WFD_v2** — how the system flows, end to end.

Together they form the full documentation set for Version 2: requirements, design, tests, onboarding, and workflow.
