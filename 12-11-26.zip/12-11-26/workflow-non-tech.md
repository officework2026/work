# WFD-Exec_v2 — Executive Workflow Document

**Project:** Lead Lifecycle Management System
**Version:** 2.0
**Audience:** Senior management, department heads, business process owners
**Companion to:** SRD_v2, SDD_v2, STD_v2, KTD_v2, WFD_v2
**Purpose:** Explain, in business terms, what each internal module does, who uses it, what information it captures, and how it produces value. No technical jargon. Every module is described as a business process with an owner, an input, an outcome, and a control.

---

## 1. Executive summary

The Lead Lifecycle Management System is the single place where every customer enquiry is captured, tracked, and converted into an order. It replaces spreadsheets, email threads, and verbal handovers with one system of record that every team in the organisation uses.

The system has **one master record** — the lead — that moves through **six ordered stages**:

1. **Enquiry** — the customer asks about a product or service.
2. **Quotation** — we send a price.
3. **Tender** — we respond to a competitive procurement.
4. **Bidding** — we submit a formal offer with terms.
5. **Order Acquisition** — the customer has chosen us; we confirm the commercial terms.
6. **Order Received** — the order is booked and the lead is `WON`.

Around that spine, the system has **eleven internal modules** that support, measure, control, or protect the process:

| # | Module | What it does for the business |
|---|---|---|
| 1 | Leads | The master record. Every enquiry lives here. |
| 2 | Quotation | Records every price we send. |
| 3 | Tender | Records every competitive bid we submit. |
| 4 | Bidding | Records every formal offer and its revisions. |
| 5 | Order Acquisition | Records the win and the commercial terms. |
| 6 | Order Received | Records the booked order. The lead closes as `WON`. |
| 7 | Bulk Upload | Lets a team enter hundreds of records at once, with errors caught before they reach the database. |
| 8 | Dashboards | Shows the pipeline, the win rate, and the forecast in real time, scoped to the viewer. |
| 9 | Radar | Shows where every lead sits across business sectors and financial years, at a glance. |
| 10 | Audit and History | Records every change to every record, by every user, forever. |
| 11 | Administration | Users, reference data, tab visibility, reference numbering, and backup. |

The rest of this document describes each module in the same business terms: **who uses it, what it captures, what it produces, what controls protect it, and how it is measured.**

---

## 2. The Lead module — the master record

### 2.1 What it is

The Lead module is the master record of every customer enquiry. Every other module in the system hangs off a lead. There is no enquiry, no quote, no tender, no bid, no order that is not attached to a lead.

### 2.2 Who uses it

| Role | What they do |
|---|---|
| **Operator** | Creates leads, updates them, advances them to the next stage. |
| **Executive** | Reviews leads, follows up on stalled ones. |
| **Administrator / Admin** | Corrects records, reassigns owners, closes leads that will not proceed. |
| **Director** | Reads across the whole company. |

### 2.3 What it captures

- Customer name, contact, and reference.
- The product or service being enquired about.
- The business domain, segment, and project (free text, with a canonical master list behind it).
- The lead source (how the enquiry arrived).
- The lead owner (the person responsible for it).
- The expected close date.
- The estimated value and currency.
- The current stage.
- The lifecycle status: **Active**, **On Hold**, **Won**, **Lost**, **Cancelled**, or **Expired**.

Every lead is created with a **company**, an **SBU**, and a **division**. These are captured at creation and never change. The **owner** can change; the owner's scope is refreshed when it does. Both the creator's scope and the owner's scope are used to decide who can see the lead.

### 2.4 What it produces

- A permanent, numbered record: `LEAD-YYYY-NNNNN`.
- A stage timeline — every transition, with the date and the person who made it.
- An audit log — every field change, with the old value and the new value.
- A list of attachments and notes.
- A place in every dashboard, every radar, and every downstream module.

### 2.5 Controls

- **Scope.** A user sees only leads created or owned within their own company, SBU, and division. An administrator in one SBU does not see another SBU's leads. A director sees the whole company on the radar and dashboards only.
- **Forward-only.** A lead cannot skip a stage. It cannot go back.
- **Advance requires data.** A lead cannot leave a stage unless that stage's module has been filled in.
- **Audit.** Every change is recorded, forever.
- **Delete is soft.** A lead is archived, not deleted.

### 2.6 How the business measures it

- **Number of leads created** per period, per SBU, per owner.
- **Conversion rate** — leads reaching `WON` divided by leads created.
- **Ageing** — how long a lead has been in its current stage.
- **Stalled leads** — leads in one stage for more than 30 days.
- **Forecast** — leads expected to close in a period, weighted by stage.

These are the numbers the Overview, Pipeline, Monthly, and Yearly dashboards surface.

---

## 3. The Quotation module — every price we send

### 3.1 What it is

The Quotation module records every price the organisation sends to a customer. A lead that reaches the `QUOTATION` stage has at least one quotation on file. If the price changes, a **revision** is recorded rather than overwriting the original.

### 3.2 Who uses it

Operators prepare quotations. Executives review them. Administrators correct them. Every quotation belongs to a lead; the quotation cannot exist on its own.

### 3.3 What it captures

- The lead reference.
- The quotation reference (our number, not the customer's).
- The date sent and the validity period.
- The line items, the quantity, the unit price, the discount, the tax, the total.
- The currency.
- The customer's reference, if they gave one.
- Free-text notes for the sales team.

Every change to a quotation creates a **revision**. The original is never overwritten.

### 3.4 What it produces

- A numbered quotation that can be traced back to a customer and forward to a tender, a bid, or an order.
- A revision history — every price we have ever offered, in order.
- An audit log.
- A place in the dashboards, so management can see what has been quoted in a period.

### 3.5 Controls

- **Scope.** Same rule as leads.
- **Revision, not overwrite.** A change to a quotation produces a new revision. Auditors can see every price the customer was offered.
- **Stage guard.** A quotation can only be created for a lead at `ENQUIRY`. Once it exists, the lead advances to `QUOTATION`.
- **Delete is logged.** A deleted quotation is still visible in the audit log.

### 3.6 How the business measures it

- **Number and value of quotations** per period, per SBU, per product.
- **Win rate from quotation** — quotations that became orders divided by quotations sent.
- **Average quote-to-close time.**
- **Average discount** — how much we give away, per SBU, per customer.

---

## 4. The Tender module — competitive procurement

### 4.1 What it is

A tender is a formal procurement exercise — typically a government or large enterprise customer — where multiple suppliers are invited to bid under a published set of rules. The Tender module captures the response we submit.

### 4.2 Who uses it

The tender team, the commercial team, and the SBU head. The tender is often the most document-heavy part of the sales cycle.

### 4.3 What it captures

- The lead reference.
- The tender reference and the customer's tender number.
- The submission deadline.
- The bidding partners, if the response is a consortium.
- The known competitors, if the customer names them or if the market is well known.
- The bid value, the currency, and the payment terms.
- The tender documents (attachments).

### 4.4 What it produces

- A tender record with a full partner and competitor picture.
- A submission record — the date, the value, the outcome.
- An audit log.
- A place in the dashboards.

### 4.5 Controls

- **Scope.** Same rule.
- **Stage guard.** A tender can only be created for a lead at `QUOTATION`. Once it exists, the lead advances to `TENDER`.
- **Partner and competitor records** are child records — they can be added, edited, and deleted independently, but each change is audited.
- **Deadline tracking.** The deadline is captured and every tender's deadline is checked by the notification service. The tender team sees a `SUBMISSION_DUE` notification seven days before.

### 4.6 How the business measures it

- **Number and value of tenders submitted** per period, per SBU.
- **Tender win rate** — tenders that became orders divided by tenders submitted.
- **Average bid value.**
- **Partner utilisation** — how often each partner appears in a winning consortium.
- **Competitor frequency** — which competitors we meet most often, and where.

---

## 5. The Bidding module — the formal offer

### 5.1 What it is

The Bidding module records the formal offer we submit after the tender response — the commercial terms that will become the order if we win.

### 5.2 Who uses it

The commercial team and the SBU head. The bid is the last step before the customer awards the order.

### 5.3 What it captures

- The lead reference.
- The bid reference and the bid date.
- The value, currency, and payment terms.
- The delivery commitment.
- The bid validity.
- **Corrigenda** — any subsequent corrections or clarifications, each with a date and a reason.

### 5.4 What it produces

- A numbered bid that can be traced back to a tender and forward to an order.
- A corrigenda list — every correction, in order.
- An audit log.
- A place in the dashboards.

### 5.5 Controls

- **Scope.** Same rule.
- **Stage guard.** A bid can only be created for a lead at `TENDER`. Once it exists, the lead advances to `BIDDING`.
- **Corrigenda are append-only.** A correction to a bid is a new record, not an edit. The original bid is preserved.
- **Validity tracking.** An expired bid is visible in the pipeline but is excluded from forecast calculations.

### 5.6 How the business measures it

- **Number and value of bids submitted** per period.
- **Bid win rate.**
- **Average corrigenda count** — how often bids need correction, which is a proxy for preparation quality.
- **Average bid value.**

---

## 6. The Order Acquisition module — the win

### 6.1 What it is

The Order Acquisition module records the moment the customer chooses us. It captures the commercial terms of the win, and the milestones that will govern the delivery.

### 6.2 Who uses it

The commercial team and the delivery team. The acquisition is the handover point between sales and operations.

### 6.3 What it captures

- The lead reference.
- The acquisition date.
- The agreed value, currency, and payment terms.
- The delivery schedule.
- The key milestones — each with a date, an owner, and a status.
- Any special terms the customer negotiated.

### 6.4 What it produces

- An acquisition record that formally marks the win.
- A milestone list that the delivery team will track.
- An audit log.
- A place in the dashboards.

### 6.5 Controls

- **Scope.** Same rule.
- **Stage guard.** An acquisition can only be created for a lead at `BIDDING`. Once it exists, the lead advances to `ORDER_ACQUISITION`.
- **Milestones are tracked.** Each milestone is a record with a date and an owner. Milestones can be updated, and every update is audited.
- **The acquisition does not close the lead.** The lead remains at `ORDER_ACQUISITION` until the order is received.

### 6.6 How the business measures it

- **Number and value of acquisitions** per period.
- **Acquisition-to-order time** — the gap between the win and the booked order. A long gap is a signal that delivery or finance is the bottleneck.
- **Milestone slip** — milestones that were missed, by SBU and by owner.

---

## 7. The Order Received module — the booked order

### 7.1 What it is

The Order Received module records the booked order. This is the final stage of the lifecycle. When the order is received, the lead closes as **WON**.

### 7.2 Who uses it

The delivery team and the finance team. The order-received record is what the finance system will see.

### 7.3 What it captures

- The lead reference.
- The order number and the order date.
- The final value, currency, and payment terms.
- The delivery commitment and the delivery address.
- The invoicing schedule.

### 7.4 What it produces

- The final record of the lead lifecycle.
- A closed lead with `lifecycle_status = WON` and `actual_close = the transition date`.
- A full audit trail from enquiry to order.
- A place in every dashboard and in the annual report.

### 7.5 Controls

- **Scope.** Same rule.
- **Stage guard.** An order-received record can only be created for a lead at `ORDER_ACQUISITION`. Once it exists, the lead advances to `ORDER_RECEIVED` and closes as `WON`.
- **The lead is frozen.** Once closed, no further module saves are accepted. Corrections after closure are made by an administrator, and each correction is audited.

### 7.6 How the business measures it

- **Number and value of orders** per period, per SBU, per product.
- **Order-to-delivery time.**
- **Order-to-cash time** — the gap between the order and the invoice.
- **Win rate** — orders divided by leads created, per period.

These are the numbers the Monthly and Yearly dashboards surface.

---

## 8. The Bulk Upload module — mass data entry

### 8.1 What it is

The Bulk Upload module lets a team enter hundreds of records at once, using a spreadsheet. Instead of typing each row into a form, an operator prepares a CSV file, uploads it, previews the parsed rows, corrects any errors, and commits.

### 8.2 Who uses it

Operators and administrators. Bulk upload is used for migration (moving existing records from a spreadsheet into the system), periodic entry (entering a month's worth of quotations at once), and correction (fixing a batch of records that were entered incorrectly).

### 8.3 The four phases

1. **Download a template.** The system gives the operator the exact CSV format for the module. No guessing.
2. **Upload and validate.** The operator uploads the filled file. The system validates every row against the same rules the form uses. Nothing is saved yet.
3. **Preview and edit.** The system opens the parsed rows in a preview. Every cell is editable. Invalid cells are highlighted with an explanation. The operator fixes errors directly in the preview.
4. **Commit.** When the operator commits, the system writes the rows to the database. If any row fails at commit (for example, a duplicate reference), the operator sees a clear error and can correct and retry.

### 8.4 Why it exists

Bulk upload solves three problems:

- **Scale.** Entering 500 records manually is not feasible.
- **Quality.** The validation catches errors before they reach the database, unlike a spreadsheet.
- **Accountability.** The audit log records every bulk job, every row, and every failed row. A batch that was entered incorrectly can be traced back.

### 8.5 Controls

- **Scope.** A user can only upload for leads in their scope. A bulk job carries the scope of the person who created it. Cross-scope jobs are visible only to administrators and the director.
- **Validation before write.** No row reaches the database unless it passes every rule. The rules are the same rules the form uses.
- **Partial commits are visible.** A commit that succeeds for most rows and fails for some is marked **Partial**. The failed rows are listed. The operator cannot claim a job succeeded when it did not.
- **Revert.** A completed job can be reverted. Every row the job created is removed. The audit log is preserved.
- **Audit.** A `BULK_UPLOAD` audit entry records the job, the operator, the number of rows, and the number of failures.

### 8.6 How the business measures it

- **Volume of bulk uploads** — how much data arrives by bulk versus form.
- **Error rate per upload** — the fraction of rows that fail on first validation. A high error rate signals a training gap.
- **Revert frequency** — how often a committed job is undone. A high revert rate signals a quality problem.

---

## 9. The Dashboards module — the numbers, scoped to the viewer

### 9.1 What it is

The Dashboards module presents seven views of the business, each scoped to the viewer's role:

| Dashboard | What it shows |
|---|---|
| **Domestic** | Leads, quotations, and orders for the domestic market. |
| **Export** | The same for the export market. |
| **Overview** | The whole pipeline, for the viewer's scope. |
| **Analysis** | Drill-downs by customer, by product, by owner. |
| **Pipeline** | The pipeline by stage, with forecast weighting. |
| **Monthly** | The month-by-month trend of orders and values. |
| **Yearly** | The year-by-year trend. |

### 9.2 Who uses it

Every role. The dashboard is the first screen after sign-in.

### 9.3 What each dashboard captures

Every dashboard reads the same data — the leads and the module records — and presents it through a common filter bar: search, year, market, stage. Every KPI card is clickable and opens the underlying rows, so a manager can see *why* a number is what it is.

### 9.4 What it produces

- **Live numbers** that replace the monthly spreadsheet exercise.
- **Consistency** — every SBU is measured the same way because every SBU uses the same dashboards.
- **Drill-down** — every headline number has a supporting list behind it.

### 9.5 Controls

- **Scope.** A user sees their own scope. An administrator sees their own scope. A director sees the whole company. This is deliberate — the overview dashboard is scoped, not global. Global visibility on the dashboards would be a security and a governance problem.
- **Consistency.** The scope rule that filters the dashboard is the same scope rule that filters the Lead list. If a lead is in a list, it is in the dashboard; if a lead is excluded from a list, it is excluded from the dashboard.
- **Freshness.** Dashboards read the live database. There is no nightly batch. A lead created at 09:00 appears on the dashboard at 09:00.
- **Drill equality.** The number on a KPI card equals the number of rows in its drill. If they disagree, it is a bug.

### 9.6 How the business measures it

The dashboards **are** the measurement. The Overview dashboard's KPIs are the numbers leadership reviews. The Monthly and Yearly dashboards produce the trend that feeds the annual plan.

---

## 10. The Radar module — where the leads sit

### 10.1 What it is

The Radar module shows a visual map of where every lead sits across two axes: the **business sector** and the **financial year**. It is a one-glance picture of the pipeline by sector and time.

There are two views:

- **SBU radar (180°)** — the caller's own SBU.
- **Full radar (360°)** — the caller's whole company. Available to directors and administrators.

### 10.2 Who uses it

Operators, executives, and administrators use the SBU view. Directors use the full view. The radar is used in leadership reviews and in quarterly planning.

### 10.3 What it captures

Nothing. The radar is read-only. It presents data that was entered elsewhere.

### 10.4 What it produces

- A **sector × year** picture of the pipeline.
- A quick way to see which sectors are well-covered and which are thin.
- A quick way to see where the pipeline is concentrated across the next five financial years.

### 10.5 Controls

- **Scope.** The SBU radar is restricted to the caller's SBU. The full radar is restricted to the caller's company. A director sees every SBU within their company but not other companies.
- **Sector visibility.** A sector with a null company is **global** — every company sees it. A sector with a company is visible only to that company. A lead in a sector is visible only if the lead is in the caller's company. This prevents a global sector from revealing another company's leads.
- **Configuration.** The radar's colours, band count, thresholds, and labels are configurable by the deployment team without a code change. The appearance can be tuned to the company's brand without a rebuild.

### 10.6 How the business measures it

- **Sector concentration** — which sectors hold the most pipeline.
- **Year concentration** — whether the pipeline is front-loaded or spread.
- **Coverage gaps** — sectors with few leads, which signal a prospecting opportunity.

---

## 11. The Audit and History module — the record of what happened

### 11.1 What it is

The Audit and History module records every change to every record, by every user, and presents it as a timeline and a diff. It is the module that allows the organisation to answer, months or years later, **who changed what, when, and why**.

### 11.2 Who uses it

Everyone, in two ways:

- **The History modal** — accessible from any record. Shows the stage timeline, the field-level changes, and the notes.
- **The module detail pages** — show the audit for the module, so an operator can see every revision of a quotation without leaving the page.

### 11.3 What it captures

For every write:

- **Who** made the change (the user).
- **When** the change was made.
- **What** changed — the field name, the old value, the new value.
- **Where** the change was made — the module, the lead reference, the record reference.
- **Why** (indirectly) — the change carries an action type: **Create**, **Update**, **Delete**, **Revision**, **Stage Advance**, **Bulk Upload**, **Download**.

### 11.4 What it produces

- A permanent, tamper-evident history of every record.
- A full lifecycle trace for a lead — from enquiry to order, with every stage, every change, and every note.
- A separate audit for each module, so an auditor can inspect a quotation's revisions without reading the lead's full history.

### 11.5 Controls

- **Every write is audited.** There is no exception. A write without an audit row is a defect.
- **The audit is immutable.** No application code deletes an audit row.
- **The audit is retained forever.** The retention policy covers it, but the application never removes it.
- **The audit is scoped.** A user sees the audit for records in their scope. An administrator sees the audit for their scope. No user sees another SBU's audit.

### 11.6 How the business measures it

The audit itself is not measured as a KPI. It is the control that allows every other KPI to be trusted. When a number on a dashboard is questioned, the audit is the answer.

---

## 12. The Administration module — users, references, configuration, backup

The Administration module is the four administrative surfaces that keep the system running. It is grouped here because it is used by administrators, not by operators.

### 12.1 User Management

**What it is.** The module where administrators create, update, and deactivate users.

**Who uses it.** Administrators and admins, within their own scope. A director can read but not edit. A superadmin cannot reach it.

**What it captures.** The user's identifier, name, role, company, SBU, division, unit, and active status. The role determines what the user can do. The scope determines what the user can see.

**Controls.**

- **Scope.** An administrator in `BEL/S1/D1` can only create, update, and delete users in `BEL/S1/D1`. They cannot create a user in `HAL` or `S2`.
- **Self-delete refused.** An administrator cannot delete their own account.
- **Role list is controlled.** The six roles are fixed. A user cannot invent a new role.
- **No superadmin here.** The superadmin is deliberately excluded from user management. The superadmin is a backup operator, not a general administrator.

### 12.2 References

**What it is.** The master data store: customers, products, currencies, lead sources, business domains, segments, projects, and received-via. Every dropdown in every form pulls from here.

**Who uses it.** Administrators edit. Everyone reads.

**What it captures.** Code, description, and scope for each master value. A master value can be global (visible to all), company-specific, SBU-specific, or division-specific.

**Controls.**

- **Scope.** An administrator edits only their own scope.
- **Service rows are hidden by default.** When a user types a new value into a free-text field and the system creates a master row automatically, that row is marked **service** and is hidden from the References page by default. This keeps the master list clean and prevents accidental deletion of auto-created values.
- **Uniqueness per scope.** The same code can exist in different scopes; the same code cannot exist twice in one scope.

### 12.3 Tab Visibility

**What it is.** A configuration that hides certain sidebar entries for certain roles or certain users.

**Who uses it.** Administrators configure it. Admins can edit the role-level matrix. Only the administrator role can edit user-level overrides.

**What it captures.** For each combination of scope, role, optional user, and tab, a visibility flag.

**Controls.**

- **Two levels.** Role-level applies to every user with the role. User-level overrides apply to one user.
- **Dense matrix.** Every cell has a value. There is no "unknown" state.
- **Deterministic resolution.** The order is: user-specific row for the caller's scope, then role-level row for the caller's scope, then a hardcoded default.
- **Not a security boundary.** Tab visibility hides an entry. It does not prevent a caller from reaching a page they are allowed to see. Role gates are the security boundary; tab visibility is the UX preference. If a page must be unreachable, the role gate does that.

### 12.4 Reference IDs

**What it is.** The configuration that controls how lead, quotation, tender, bid, acquisition, and order reference numbers are generated. Templates like `LEAD-{YYYY}-{SEQ:5}` are editable at runtime.

**Who uses it.** Administrators.

**What it captures.** One template per reference type.

**Controls.**

- **Runtime editable.** A change to a template takes effect on the next reference. No rebuild, no restart.
- **Live example.** The page shows a live example for each template, computed from the current date and the current sequence, so a wrong template is caught before it is saved.
- **Only admin-like can edit.** The reference formats are configured by administrators only.

### 12.5 Backup and Restore

**What it is.** The system's data protection module. It produces a full database backup on a schedule and on demand, and it restores from a backup if the database is damaged.

**Who uses it.** **Superadmin only.** No other role, including the administrator, can reach it.

**What it captures.** A compressed SQL dump of the database, optionally a copy of the attachments folder, and a record of who triggered the run, when, and whether it succeeded.

**Controls.**

- **Superadmin isolation.** The superadmin sees every backup across every company. The administrator sees none. This is deliberate — a backup that only covers one SBU would not be a backup, it would be a fragment, and a restore from it would overwrite other SBUs' data. Backup and restore is a whole-system operation.
- **Scheduled and manual.** A daily backup at 02:00 by default. An administrator can also trigger a backup on demand.
- **Retention.** The system keeps the most recent N backups. Older ones are pruned.
- **Safety backup before restore.** Before any restore, the system takes a fresh backup. If the restore fails, the safety backup is the recovery path.
- **Diagnostics.** A diagnostic screen reports the resolved path of the PostgreSQL tools, their version strings, and whether the backup and uploads directories exist. The first line of defence when a backup fails.

---

## 13. The role map — who can do what

The system's permissions are governed by six roles. The table below shows the intent of each role from the business point of view.

| Role | Intent | Sees | Can do |
|---|---|---|---|
| **Operator** | Front-line data entry. | Own scope. | Create, update, advance leads. Save module records. Use bulk upload. |
| **Executive** | Supervisory review. | Own scope. | The same as operator, plus review and follow-up. |
| **Admin** | Administrative within an SBU. | Own scope. | The same as executive, plus user management, references, and the role-level tab matrix. |
| **Administrator** | Senior administrative within an SBU. | Own scope. | Everything an admin can do, plus user-level tab overrides. |
| **Director** | Company-wide viewer. | Whole company on the radar and dashboards. Own scope elsewhere. | Read everything in the company. |
| **Superadmin** | Backup operator. | Every backup. Nothing else. | Backup and restore only. |

Two rules govern every role:

1. **Admin-like does not bypass scope.** An administrator in `BEL/S1/D1` sees only `BEL/S1/D1` on every module, every dashboard, every user list. The only role with a scope exception is the director, and the exception applies only to the radar and dashboards.
2. **The superadmin is deliberately narrow.** The superadmin cannot reach user management, references, or tab visibility. The role exists to protect the data, not to change it. If a business user asks for the superadmin to also do something else, the answer is to create an administrator with that responsibility in a specific scope, not to widen the superadmin.

---

## 14. The controls that protect the business

Three controls cut across every module. They are the reason the system can be trusted with the organisation's commercial record.

### 14.1 Scope — the visibility control

A user sees only what their company, SBU, and division allows. This is enforced on every read and every write, on every module, on every dashboard, on every user list, on every reference, on every bulk job, on every history endpoint.

The two exceptions — the director on the radar and dashboards, and the superadmin on backup — are named, documented, and tested. No other exception exists.

The business consequence: **one SBU cannot see another SBU's commercial pipeline.** This is a governance requirement, not a technical preference. The system enforces it in a single function per service, so a change that weakened it would be caught in review and in the cross-scope test gate.

### 14.2 Audit — the accountability control

Every write, every change, every stage transition, every revision, every bulk commit, every download, is recorded. The record carries the person, the time, the old state, the new state, and a field-level diff.

The business consequence: **every number on every dashboard can be traced to the events that produced it.** When an auditor asks "why does the pipeline show 42 orders?", the answer is a list of 42 events, each with a person and a time.

The audit is immutable, retained forever, and scoped to the user who reads it.

### 14.3 Transaction — the consistency control

Every multi-step write — creating a lead, saving a module record, advancing a stage, committing a bulk job — happens inside a single transaction. Either every step succeeds or every step is rolled back.

The business consequence: **there is no state where a lead has advanced but its module row is missing, or where a quotation exists but its revision does not.** The database cannot be left in an inconsistent state by a partial write.

The one deliberate exception is the bulk commit, where each row is its own transaction. A partial commit is a supported outcome, and it is recorded as **Partial** with the failed rows listed. This is safer than a single transaction, which would mean that one bad row rolls back the whole batch — and the operator loses hours of work.

---

## 15. The value of the system, in one page

For the executive reader who has five minutes, this is the case for the system.

### 15.1 What it replaces

- **Spreadsheets** — no longer the source of truth. One system of record.
- **Email threads** — no longer where the details live. Everything is attached to the lead.
- **Verbal handovers** — no longer the way a lead moves between teams. Every stage is a record.
- **Manual monthly reporting** — no longer a spreadsheet exercise. The dashboards are live.

### 15.2 What it enables

- **Live visibility** of the pipeline, by stage, by SBU, by owner, by sector, by financial year.
- **Consistent measurement** across SBUs, because every SBU uses the same dashboards.
- **Accountability** — every change is recorded, with a person and a time.
- **Governance** — the scope rule keeps SBUs from seeing each other's pipeline, which is a requirement for a multi-SBU organisation.
- **Data protection** — a superadmin-operated backup keeps the whole system recoverable.
- **Scalability** — bulk upload lets a team enter a month's worth of data in an hour.

### 15.3 What it costs to operate

- Three server processes and one database. No external dependencies beyond PostgreSQL.
- One administrator per SBU for user management, references, and tab visibility.
- One superadmin for backup. The superadmin is a backup operator, not a general administrator. This is by design.
- The system runs on the internal network. It is not exposed to the internet.

### 15.4 What the roadmap requires

The system is in Version 2. The baseline is complete. Future work is scoped by the SRD, designed by the SDD, tested by the STD, and onboarded through the KTD. A change that touches the scope rule, the audit rule, or the transaction boundary is reviewed by a second engineer and gated by the cross-scope test suite. That is the process that keeps the system trustworthy as it evolves.

---

## 16. Appendix — module summary table

| Module | Owner role | Primary input | Primary output | Primary control | Primary KPI |
|---|---|---|---|---|---|
| Leads | Operator | Customer enquiry | Numbered lead record | Scope + audit | Conversion rate |
| Quotation | Operator | Price to offer | Numbered quotation with revisions | Revision, not overwrite | Win rate from quote |
| Tender | Tender team | Competitive procurement | Tender record with partners and competitors | Deadline tracking | Tender win rate |
| Bidding | Commercial team | Formal offer | Numbered bid with corrigenda | Append-only corrigenda | Bid win rate |
| Order Acquisition | Commercial + delivery | Customer decision | Acquisition record with milestones | Milestone tracking | Acquisition-to-order time |
| Order Received | Delivery + finance | Booked order | Closed lead with `WON` | Frozen after closure | Order value |
| Bulk Upload | Operator + admin | CSV file | Validated batch of records | Validation before write | Error rate per upload |
| Dashboards | All | Live data | Seven scoped dashboards | Same scope rule as leads | The KPIs themselves |
| Radar | All (SBU), director (full) | Live data | Sector × year visual | Company clause | Sector and year concentration |
| Audit and History | All | Every write | Full lifecycle trace | Immutable | The audit is the measurement |
| User Management | Administrator | New user | User record | Scope + self-delete refused | Active users per scope |
| References | Administrator | Master value | Master record | Service rows hidden | Master data consistency |
| Tab Visibility | Administrator | Visibility preference | Sidebar layout | Dense matrix | — (a preference, not a metric) |
| Reference IDs | Administrator | Reference template | Numbered records | Runtime editability | — (a configuration, not a metric) |
| Backup | Superadmin | Schedule or manual run | SQL dump + attachments copy | Superadmin isolation | Backup success rate |

---

## 17. Glossary for the business reader

| Term | Meaning |
|---|---|
| **Lead** | A customer enquiry that is being tracked to an order. |
| **Stage** | One of the six ordered steps a lead moves through. |
| **Module** | One of the six stage-specific data-capture pages. |
| **Scope** | The company, SBU, and division that determines what a user can see. |
| **Admin-like** | Any role that has administrative responsibilities within its own scope. Does not bypass scope. |
| **Director** | A role that sees the whole company on the radar and dashboards. |
| **Superadmin** | A role that is exclusively for backup and restore. |
| **Bulk upload** | A CSV-based way to enter many records at once, with validation and a preview. |
| **Audit log** | The permanent record of every change to every record. |
| **Reference** | A numbered identifier for a lead, a quotation, a tender, a bid, an acquisition, or an order. |
| **Tab visibility** | The configuration that hides certain sidebar entries for certain roles. |
| **Reconcile** | To trace a number on a dashboard back to the underlying records. The audit log is the reconciliation tool. |
| **Advance** | To move a lead from its current stage to the next stage. |
| **Correct** | To change a value on a record. Every correction is audited. |
| **Archive** | To retire a lead without deleting it. The record remains visible in the audit. |

---

**End of WFD-Exec_v2.**

This document is the business-facing companion to the technical workflow document. It is written for the senior reader who needs to understand what the system does, who uses it, and how it produces value — without the code, the schema, or the API. It is deliberately short enough to read in one sitting, and long enough to answer the questions that come up in a management review: **who owns this, what does it record, what does it produce, what protects it, and how do we measure it.**

Together with the four technical documents, it completes the documentation set for Version 2:

- **SRD_v2** — what the system must do.
- **SDD_v2** — how the system is built.
- **STD_v2** — how each requirement is proven.
- **KTD_v2** — how a new engineer learns the system.
- **WFD_v2** — how the system flows, end to end, in technical terms.
- **WFD-Exec_v2** — how the system delivers value, module by module, in business terms.
